import os
import cv2
import numpy as np
import math

def yolo_txt_to_mask(txt_path, image_shape):
    """
    Convert YOLOv8 txt annotations to a binary mask.
    """
    mask = np.zeros(image_shape[:2], dtype=np.uint8)
    with open(txt_path, 'r') as file:
        for line in file:
            data = line.strip().split()
            class_id = int(data[0])  # Class ID (not used in mask generation)
            coords = list(map(float, data[1:]))
            points = [(int(coords[i] * image_shape[1]), int(coords[i + 1] * image_shape[0]))
                      for i in range(0, len(coords), 2)]
            cv2.fillPoly(mask, [np.array(points, dtype=np.int32)], 255)
    return mask

def extract_navigation_line(mask):
    """
    Extract top and bottom points of the mask for navigation line calculation.
    """
    height, width = mask.shape
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Center of the image
    image_center = (width // 2, height // 2)

    # Store navigation lines
    navigation_lines = []

    for contour in contours:
        points = np.squeeze(contour)
        if len(points.shape) != 2:
            continue

        vertical_projection = {}
        for point in points:
            x, y = point
            if y not in vertical_projection:
                vertical_projection[y] = []
            vertical_projection[y].append(x)

        top_y = min(vertical_projection.keys())
        bottom_y = max(vertical_projection.keys())

        top_center = (int(np.mean(vertical_projection[top_y])), top_y)
        bottom_center = (int(np.mean(vertical_projection[bottom_y])), bottom_y)

        navigation_lines.append((top_center, bottom_center))

    if len(navigation_lines) == 0:
        return None

    # Select the navigation line with the closest distance to the center
    min_distance = float('inf')
    best_line = None
    for line in navigation_lines:
        top_center, bottom_center = line
        avg_center = ((top_center[0] + bottom_center[0]) // 2, (top_center[1] + bottom_center[1]) // 2)

        dx = bottom_center[0] - top_center[0]
        dy = bottom_center[1] - top_center[1]

        numerator = abs(dy * image_center[0] - dx * image_center[1] + bottom_center[0] * top_center[1] - bottom_center[1] * top_center[0])
        denominator = np.sqrt(dx**2 + dy**2)
        distance = numerator / denominator

        if distance < min_distance:
            min_distance = distance
            best_line = line

    return best_line

def calculate_angle_diff(line1, line2):
    """
    Calculate the angle difference between two lines based on their slopes.
    """
    def slope(line):
        top_center, bottom_center = line
        if bottom_center[0] == top_center[0]:
            return float('inf')  # Vertical line
        return (bottom_center[1] - top_center[1]) / (bottom_center[0] - top_center[0])

    slope1 = slope(line1)
    slope2 = slope(line2)

    # Calculate the angle difference
    angle1 = math.atan(slope1) if slope1 != float('inf') else math.pi / 2
    angle2 = math.atan(slope2) if slope2 != float('inf') else math.pi / 2

    angle_diff = abs(angle1 - angle2) * 180 / math.pi  # Convert to degrees
    return angle_diff

def calculate_distance_diff(line1, line2):
    """
    Calculate the horizontal distance difference at the top and bottom of the two lines.
    """
    top1, bottom1 = line1
    top2, bottom2 = line2

    # Calculate horizontal distance at the top and bottom
    top_distance = abs(top1[0] - top2[0])
    bottom_distance = abs(bottom1[0] - bottom2[0])

    # Average distance
    return (top_distance + bottom_distance) / 2

def process_images(image_folder, pred_txt_folder, label_txt_folder, output_folder):
    """
    Process images to extract and visualize navigation lines, compute angle and distance differences.
    """
    angle_diffs = []
    distance_diffs = []
    count = 0

    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for image_name in os.listdir(image_folder):
        if not image_name.endswith(('.jpg', '.png')):
            continue

        image_path = os.path.join(image_folder, image_name)
        pred_txt_path = os.path.join(pred_txt_folder, os.path.splitext(image_name)[0] + '.txt')
        label_txt_path = os.path.join(label_txt_folder, os.path.splitext(image_name)[0] + '.txt')

        if not os.path.exists(pred_txt_path) or not os.path.exists(label_txt_path):
            print(f"Skipping {image_name}, missing corresponding txt files.")
            continue

        image = cv2.imread(image_path)

        # Convert txt annotations to masks
        pred_mask = yolo_txt_to_mask(pred_txt_path, image.shape)
        label_mask = yolo_txt_to_mask(label_txt_path, image.shape)

        # Extract navigation lines
        pred_line = extract_navigation_line(pred_mask)
        label_line = extract_navigation_line(label_mask)

        if pred_line and label_line:
            # Calculate angle difference and distance difference
            angle_diff = calculate_angle_diff(pred_line, label_line)
            distance_diff = calculate_distance_diff(pred_line, label_line)

            # Filter based on conditions
            if angle_diff <= 15 and distance_diff <= 20:
                angle_diffs.append(angle_diff)
                distance_diffs.append(distance_diff)
                count += 1

            # Draw navigation lines on the image
            cv2.line(image, pred_line[0], pred_line[1], (0, 255, 0), 2)  # Green for prediction
            cv2.line(image, label_line[0], label_line[1], (0, 0, 255), 2)  # Red for ground truth

        # Save the result
        output_path = os.path.join(output_folder, image_name)
        cv2.imwrite(output_path, image)

    # Save results to a text file
    if count > 0:
        avg_angle_diff = np.mean(angle_diffs)
        avg_distance_diff = np.mean(distance_diffs)

        result_txt_path = os.path.join(output_folder, "angle_distance_diff_results.txt")
        with open(result_txt_path, 'w') as f:
            f.write(f"Number of valid images: {count}\n")
            f.write(f"Average Angle Difference: {avg_angle_diff:.2f} degrees\n")
            f.write(f"Average Distance Difference: {avg_distance_diff:.2f} pixels\n")
    else:
        print("No valid images found based on angle and distance criteria.")

# Example usage
image_folder = r"D:\BaiduNetdiskDownload\111\valid\images"  #图片地址
pred_txt_folder = r"C:\Users\win10\Desktop\ultralytics-20241204\ultralytics-main\runs\detect\exp13\labels"  #预测的掩码txt文件
label_txt_folder = r"D:\BaiduNetdiskDownload\111\valid\labels" #掩码标签文件对应的txt
output_folder = r"C:\Users\win10\Desktop\output\exp33"  #结果保存的文档

process_images(image_folder, pred_txt_folder, label_txt_folder, output_folder)
