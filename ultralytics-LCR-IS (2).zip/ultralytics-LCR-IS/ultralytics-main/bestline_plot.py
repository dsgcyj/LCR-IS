import cv2
import numpy as np

def extract_navigation_lines(mask, num_lines=3):
    height, width = mask.shape[:2]

    # 如果是三通道图像，则转为灰度图像
    if len(mask.shape) == 3:
        mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)

    # 二值化处理
    _, mask = cv2.threshold(mask, 127, 255, cv2.THRESH_BINARY)

    # 找到所有轮廓
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # 图像中心
    image_center = (width // 2, height // 2)

    # 存储每个掩码的上下中心点
    center_points = []
    for contour in contours:
        # 获取最小外接矩形
        rect = cv2.minAreaRect(contour)
        box = cv2.boxPoints(rect)
        box = np.intp(box)

        # 排序角点，找到上下边界
        sorted_box = sorted(box, key=lambda x: x[1])  # 按Y排序
        top_left, top_right = sorted_box[:2]
        bottom_left, bottom_right = sorted_box[2:]

        # 计算上下中心点
        top_center = ((top_left[0] + top_right[0]) // 2, (top_left[1] + top_right[1]) // 2)
        bottom_center = ((bottom_left[0] + bottom_right[0]) // 2, (bottom_left[1] + bottom_right[1]) // 2)

        # 添加到中心点列表
        center_points.append((top_center, bottom_center))

    # 按与图像中心的距离排序，取最接近的num_lines条
    center_points.sort(key=lambda x: np.sqrt((x[0][0] - image_center[0])**2 + (x[0][1] - image_center[1])**2))
    return center_points[:num_lines]

def extend_line_to_image_boundary(point1, point2, width, height):
    # 根据两点计算直线方程 y = ax + b
    x1, y1 = point1
    x2, y2 = point2
    if x1 == x2:  # 垂直线
        return (x1, 0), (x1, height - 1)
    else:
        a = (y2 - y1) / (x2 - x1)
        b = y1 - a * x1

        # 计算与上下边界的交点
        top_intersect = (int(-b / a), 0)
        bottom_intersect = (int((height - 1 - b) / a), height - 1)

        # 限制交点在图像范围内
        top_intersect = max(0, min(width - 1, top_intersect[0])), top_intersect[1]
        bottom_intersect = max(0, min(width - 1, bottom_intersect[0])), bottom_intersect[1]

        return top_intersect, bottom_intersect

def visualize_navigation_lines(mask_image_path, save_image_path, num_lines=3):
    mask_image = cv2.imread(mask_image_path)
    height, width = mask_image.shape[:2]

    # 提取导航线
    navigation_lines = extract_navigation_lines(mask_image, num_lines)

    # 存储所有交点
    top_intersects = []
    bottom_intersects = []

    # 绘制每条导航线
    for top_center, bottom_center in navigation_lines:
        # 计算延长线的交点
        top_intersect, bottom_intersect = extend_line_to_image_boundary(top_center, bottom_center, width, height)

        # 绘制延长线
        cv2.line(mask_image, top_intersect, bottom_intersect, (255, 0, 255), 2)  # 紫色线条

        # 标记交点
        cv2.circle(mask_image, top_intersect, 5, (0, 255, 0), -1)  # 绿色圆点（顶部）
        cv2.circle(mask_image, bottom_intersect, 5, (255, 0, 0), -1)  # 蓝色圆点（底部）

        # 保存交点
        top_intersects.append(top_intersect)
        bottom_intersects.append(bottom_intersect)

    # 计算红线的上下端点
    if top_intersects and bottom_intersects:
        avg_top = (
            sum(point[0] for point in top_intersects) // len(top_intersects),
            sum(point[1] for point in top_intersects) // len(top_intersects)
        )
        avg_bottom = (
            sum(point[0] for point in bottom_intersects) // len(bottom_intersects),
            sum(point[1] for point in bottom_intersects) // len(bottom_intersects)
        )

        # 绘制红线
        cv2.line(mask_image, avg_top, avg_bottom, (0, 0, 255), 2)  # 红色线条

    # 保存结果
    cv2.imwrite(save_image_path, mask_image)

if __name__ == "__main__":
    mask_image_path = r"C:\Users\win10\Desktop\CropRowDetection-main\unet-rgbd\results\image\81.jpg"  # 输入掩码路径
    save_image_path = r"C:\Users\win10\Desktop\ultralytics-20241204\ultralytics-main\runs\detect\result\81_hangxian.jpg"  # 输出结果路径

    visualize_navigation_lines(mask_image_path, save_image_path)
